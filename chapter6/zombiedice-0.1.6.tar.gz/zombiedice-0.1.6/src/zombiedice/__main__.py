import zombiedice


if __name__ == '__main__':
    zombiedice.demo()